package it.unipi.inventorymanager.controllers;

import it.unipi.inventorymanager.entities.Tipo;
import it.unipi.inventorymanager.repositories.TipoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tipi")
@CrossOrigin(origins = "*")
public class TipoController {

    @Autowired
    private TipoRepository tipoRepository;

    @GetMapping
    public List<Tipo> getAllTipi() {
        return tipoRepository.findAll();
    }
}