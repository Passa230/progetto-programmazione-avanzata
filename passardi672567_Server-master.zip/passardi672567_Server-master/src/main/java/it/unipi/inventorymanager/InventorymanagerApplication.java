package it.unipi.inventorymanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventorymanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventorymanagerApplication.class, args);
	}

}
