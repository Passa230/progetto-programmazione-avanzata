package it.unipi.inventorymanager.controllers;

import it.unipi.inventorymanager.dtos.MagazzinoRequest;
import it.unipi.inventorymanager.dtos.response.MagazzinoResponse;
import it.unipi.inventorymanager.entities.Magazzino;
import it.unipi.inventorymanager.repositories.MagazzinoRepository;
import it.unipi.inventorymanager.services.MagazzinoService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/magazzini")
@RequiredArgsConstructor
public class MagazzinoController {
    @Autowired
    private MagazzinoRepository repository;
    @Autowired
    private MagazzinoService service;

    @GetMapping("/utente/{id}")
    public List<MagazzinoResponse> getMagazzini(@PathVariable Long id) {
        List<Magazzino> listaMagazzini = repository.findByUtenteId(id);

        List<MagazzinoResponse> listaRisposta = new ArrayList<>();

        for (Magazzino m : listaMagazzini) {
            MagazzinoResponse response = new MagazzinoResponse(
                    m.getId(),
                    m.getNome(),
                    m.getIndirizzo()
            );
            listaRisposta.add(response);
        }

        return listaRisposta;
    }

    @PostMapping("/crea")
    public Magazzino creaMagazzino(@RequestBody MagazzinoRequest request) {
        return service.salvaNuovoMagazzino(request);
    }

    @DeleteMapping("/elimina/{id}")
    public void eliminaMagazzino(@PathVariable Long id) {
        this.service.eliminaMagazzino(id);
    }


}
