package it.unipi.inventorymanager.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegisterRequest {
    private String username;
    private String password;
    private String nome;
    private String cognome;
    private String codFiscale;
    private String telefono;
    private String ruolo;
    private String email;
    private String dataNascita;
}