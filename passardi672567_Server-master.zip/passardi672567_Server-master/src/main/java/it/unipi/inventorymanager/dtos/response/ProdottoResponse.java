package it.unipi.inventorymanager.dtos.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProdottoResponse {
    private Long id;
    private String codiceSku;
    private String nome;
    private String descrizione;
    private Integer quantita;
    private Double prezzo;
    private String nomeTipo;
    private String nomeMagazzino;
}

