package it.unipi.inventorymanager.repositories;

import it.unipi.inventorymanager.entities.Transazione;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TransazioneRepository extends JpaRepository<Transazione,Long> {
    List<Transazione> findByProdottoIdOrderByDataMovimentoDesc(Long prodottoId);

    List<Transazione> findByMagazzinoDaIdOrMagazzinoAIdOrderByDataMovimentoDesc(Long magazzinoDaId, Long magazzinoAId);

    @Query("SELECT t FROM Transazione t " +
            "WHERE (:magazzinoDaId IS NULL OR t.magazzinoDa.id = :magazzinoDaId) " +
            "AND (:magazzinoAId IS NULL OR t.magazzinoA.id = :magazzinoAId) " +
            "AND (:searchField IS NULL OR LOWER(t.prodotto.nome) LIKE LOWER(CONCAT('%', :searchField, '%'))) " +
            "ORDER BY t.dataMovimento DESC")
    List<Transazione> cercaConFiltri(
            @Param("magazzinoDaId") Long magazzinoDaId,
            @Param("magazzinoAId") Long magazzinoAId,
            @Param("searchField") String searchField
    );
}
