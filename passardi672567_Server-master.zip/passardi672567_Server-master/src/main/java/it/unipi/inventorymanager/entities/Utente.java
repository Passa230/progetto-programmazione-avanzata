package it.unipi.inventorymanager.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Past;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Table(name = "utenti")
@Data @NoArgsConstructor @AllArgsConstructor
public class Utente implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false, unique = true, name = "codice_fiscale")
    private String codFiscale;

    private String nome;
    private String cognome;

    @Past       // Validator --> Assicura che la data sia nel passato
    @Column(name = "data_nascita")
    private LocalDate dataNascita;

    @Email      // Validator --> Assicura che la email sia nel corretto formato
    private String email;

    private String telefono;
    private String ruolo;
}
