package it.unipi.inventorymanager.controllers;

import it.unipi.inventorymanager.dtos.SearchTransactionRequest;
import it.unipi.inventorymanager.dtos.TransazioneRequest;
import it.unipi.inventorymanager.dtos.response.TransazioneResponse;
import it.unipi.inventorymanager.entities.Transazione;
import it.unipi.inventorymanager.services.TransazioneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transazioni")
public class TransazioniController {

    @Autowired
    private TransazioneService transazioneService;

    @PostMapping("/aggiungi")
    public Transazione aggiungiTransazione(@RequestBody TransazioneRequest transazione) {
        return transazioneService.createTransazione(transazione);
    }


    @PostMapping("/cerca/")
    public List<TransazioneResponse> scaricaTransazioneMagazzini(@RequestBody SearchTransactionRequest transazione) {
        return transazioneService.findByUserFilter(transazione);
    }

}
