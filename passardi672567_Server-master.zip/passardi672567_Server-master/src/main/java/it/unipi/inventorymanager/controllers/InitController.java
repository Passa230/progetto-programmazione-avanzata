package it.unipi.inventorymanager.controllers;

import ch.qos.logback.classic.Logger;
import it.unipi.inventorymanager.dtos.response.Response;
import it.unipi.inventorymanager.services.InitService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/init")
@RequiredArgsConstructor
public class InitController {
    @Autowired
    private InitService initService;

    @GetMapping("/")
    public ResponseEntity<Response> inizializzaServizio(){
        try {
            initService.refreshDatabase();

            return ResponseEntity.ok(new Response(true, "Database inizializzato con successo"));
        }
        catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new Response(false, "Errore durante l'inizializzazione: " + e.getMessage()));
        }
    }
}
