package it.unipi.inventorymanager.controllers;

import it.unipi.inventorymanager.dtos.ProdottoRequest;
import it.unipi.inventorymanager.dtos.RicercaRequest;
import it.unipi.inventorymanager.dtos.response.ProdottoResponse;
import it.unipi.inventorymanager.entities.Prodotto;
import it.unipi.inventorymanager.services.ProdottoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/prodotti")
public class ProdottoController {
    @Autowired
    private ProdottoService prodottoService;

    @GetMapping("/magazzino/{id}")
    public List<ProdottoResponse> getProdottiByMagazzino(@PathVariable Long id) {
        return prodottoService.findProdottiByMagazzinoId(id);
    }

    @PostMapping("/crea")
    public Prodotto creaProdotto(@RequestBody ProdottoRequest prodottoRequest){
        return prodottoService.creaProdotto(prodottoRequest);
    }

    @PostMapping("/cerca")
    public List<ProdottoResponse> cercaProdotti(@RequestBody RicercaRequest ricercaRequest){
        return prodottoService.cercaProdotto(ricercaRequest);
    }

    @GetMapping("/all/{id}")
    public List<ProdottoResponse> getProdottiByUserId(@PathVariable Long id) {
        return prodottoService.findProdottiByUserId(id);
    }
}
