package it.unipi.inventorymanager.services;

import it.unipi.inventorymanager.dtos.RegisterRequest;
import it.unipi.inventorymanager.repositories.UtenteRepository;
import it.unipi.inventorymanager.entities.Utente;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UtenteRepository utenteRepository;
    private final PasswordEncoder passwordEncoder;

    /**
     * Verifica le credenziali dell'utente.
     * @param username Lo username inserito in JavaFX
     * @param password La password in chiaro inserita in JavaFX
     * @return true se le credenziali sono corrette, false altrimenti
     */
    public boolean autentica(String username, String password) {
        Optional<Utente> utenteOpt = utenteRepository.findByUsername(username);

        if (utenteOpt.isPresent()) {
            Utente utente = utenteOpt.get();
            return passwordEncoder.matches(password, utente.getPassword());
        }

        return false;
    }

    @Transactional
    public boolean registra(RegisterRequest request) {
        if (utenteRepository.findByUsername(request.getUsername()).isPresent()) {
            return false;
        }


        Utente nuovoUtente = new Utente();
        nuovoUtente.setUsername(request.getUsername());
        nuovoUtente.setPassword(passwordEncoder.encode(request.getPassword()));
        nuovoUtente.setNome(request.getNome());
        nuovoUtente.setCognome(request.getCognome());
        nuovoUtente.setCodFiscale(request.getCodFiscale());
        nuovoUtente.setTelefono(request.getTelefono());
        nuovoUtente.setEmail(request.getEmail());
        nuovoUtente.setRuolo("OWNER_MAGAZZINO");
        nuovoUtente.setDataNascita(LocalDate.parse(request.getDataNascita()));

        utenteRepository.save(nuovoUtente);
        return true;
    }

    public Utente findByUsername(String username) {
        return utenteRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Utente non trovato"));
    }
}