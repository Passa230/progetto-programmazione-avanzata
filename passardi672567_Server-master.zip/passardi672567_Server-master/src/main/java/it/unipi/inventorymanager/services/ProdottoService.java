package it.unipi.inventorymanager.services;

import it.unipi.inventorymanager.dtos.ProdottoRequest;
import it.unipi.inventorymanager.dtos.RicercaRequest;
import it.unipi.inventorymanager.dtos.response.MagazzinoResponse;
import it.unipi.inventorymanager.dtos.response.ProdottoResponse;
import it.unipi.inventorymanager.entities.Magazzino;
import it.unipi.inventorymanager.entities.Prodotto;
import it.unipi.inventorymanager.entities.Tipo;
import it.unipi.inventorymanager.repositories.MagazzinoRepository;
import it.unipi.inventorymanager.repositories.ProdottoRepository;
import it.unipi.inventorymanager.repositories.TipoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProdottoService {
    @Autowired
    private ProdottoRepository prodottoRepository;

    @Autowired
    private MagazzinoRepository magazzinoRepository;

    @Autowired
    private TipoRepository tipoRepository;

    public List<ProdottoResponse> findProdottiByMagazzinoId(Long magazzinoId) {
        List<Prodotto> entita = prodottoRepository.findByMagazzinoId(magazzinoId);

        List<ProdottoResponse> listaPulita = new ArrayList<>();

        for (Prodotto p : entita) {
            String nomeTipo = (p.getTipo() != null) ? p.getTipo().getNome() : "N/A";

            listaPulita.add(new ProdottoResponse(
                    p.getId(),
                    p.getCodiceSku(),
                    p.getNome(),
                    p.getDescrizione(),
                    p.getQuantita(),
                    p.getPrezzo(),
                    nomeTipo,
                    p.getMagazzino().getNome()
            ));
        }

        return listaPulita;
    }

    public Prodotto creaProdotto(ProdottoRequest prodottoRequest) {
        Magazzino magazzino = magazzinoRepository.findById(prodottoRequest.getMagazzinoId())
                .orElseThrow(() -> new RuntimeException("Magazzino non trovato"));

        Tipo tipoTrovato = null;
        if (prodottoRequest.getNomeTipo() != null && !prodottoRequest.getNomeTipo().isEmpty()) {
            tipoTrovato = tipoRepository.findByNome(prodottoRequest.getNomeTipo())
                    .orElse(null);
        }
        Prodotto p = new Prodotto();
        //p.setId(prodottoRequest.getId());
        p.setNome(prodottoRequest.getNome());
        p.setQuantita(prodottoRequest.getQuantita());
        p.setPrezzo(prodottoRequest.getPrezzo());
        p.setDescrizione(prodottoRequest.getDescrizione());
        p.setCodiceSku(prodottoRequest.getCodiceSku());
        p.setMagazzino(magazzino);
        p.setTipo(tipoTrovato);

        return prodottoRepository.save(p);
    }

    public List<ProdottoResponse> cercaProdotto(RicercaRequest ricercaRequest) {
        List<ProdottoResponse> list = new ArrayList<>();

        String filter = ricercaRequest.getNomeFiltro();
        String query = ricercaRequest.getTesto();
        Long id = ricercaRequest.getUserId();

        if (filter == null || query == null) return new ArrayList<>();

        List<Prodotto> searchResult = new ArrayList<>();
        switch (filter) {

            case "nome":
                searchResult = prodottoRepository.findByMagazzino_Utente_IdAndDescrizioneContainingIgnoreCase(id, query);
                break;
            case "sku":
            case "codiceSku":
                searchResult = prodottoRepository.findByCodiceSku(query);
                break;
            case "descrizione":
                searchResult = prodottoRepository.findByMagazzino_Utente_IdAndDescrizioneContainingIgnoreCase(id, query);
                break;
            case "tipo":
            case "nometipo":
                Optional<Tipo> tipoTrovato = tipoRepository.findByNome(query);
                if (tipoTrovato.isPresent()) {
                    searchResult = prodottoRepository.findByTipoId(tipoTrovato.get().getId());
                } else {
                    searchResult = new ArrayList<>();
                }
                break;
            default:
                searchResult = prodottoRepository.findByMagazzino_Utente_IdAndNomeContainingIgnoreCase(id, query);
                break;
        }

        if (searchResult == null) {return list;}

        for (Prodotto p: searchResult){
            ProdottoResponse tmp = new ProdottoResponse();
            tmp.setId(p.getId());
            tmp.setCodiceSku(p.getCodiceSku());
            tmp.setDescrizione(p.getDescrizione());
            tmp.setQuantita(p.getQuantita());
            tmp.setPrezzo(p.getPrezzo());
            tmp.setNome(p.getNome());
            String nomeTipo = (p.getTipo() != null) ? p.getTipo().getNome() : "N/A";
            tmp.setNomeTipo(nomeTipo);
            tmp.setNomeMagazzino(p.getMagazzino().getNome());

            list.add(tmp);
        }

        return list;
    }

    public List<ProdottoResponse> findProdottiByUserId(Long id) {
        List<ProdottoResponse> list = new ArrayList<>();

        List<Magazzino> l = magazzinoRepository.findByUtenteId(id);

        for (Magazzino m: l) {
            List<Prodotto> tmp = prodottoRepository.findByMagazzinoId(m.getId());

            for (Prodotto p: tmp) {
                ProdottoResponse tmp2 = new ProdottoResponse();
                tmp2.setId(p.getId());
                tmp2.setCodiceSku(p.getCodiceSku());
                tmp2.setDescrizione(p.getDescrizione());
                tmp2.setQuantita(p.getQuantita());
                tmp2.setPrezzo(p.getPrezzo());
                tmp2.setNome(p.getNome());
                String nomeTipo = (p.getTipo() != null) ? p.getTipo().getNome() : "N/A";
                tmp2.setNomeTipo(nomeTipo);
                tmp2.setNomeMagazzino(p.getMagazzino().getNome());
                list.add(tmp2);
            }
        }

        return list;
    }
}
