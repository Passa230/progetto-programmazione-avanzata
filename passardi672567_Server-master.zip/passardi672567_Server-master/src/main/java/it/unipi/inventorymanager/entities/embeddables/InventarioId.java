package it.unipi.inventorymanager.entities.embeddables;

import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Embeddable
@Data @NoArgsConstructor @AllArgsConstructor
public class InventarioId implements Serializable {
    private Long magazzinoId;
    private Long prodottoId;
}

