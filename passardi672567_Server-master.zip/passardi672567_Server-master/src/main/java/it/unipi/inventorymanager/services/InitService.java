package it.unipi.inventorymanager.services;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.unipi.inventorymanager.entities.Magazzino;
import it.unipi.inventorymanager.entities.Prodotto;
import it.unipi.inventorymanager.entities.Tipo;
import it.unipi.inventorymanager.entities.Utente;
import it.unipi.inventorymanager.repositories.*;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class InitService {
    private final MagazzinoRepository magazzinoRepository;
    private final TransazioneRepository transazioneRepository;
    private final ProdottoRepository prodottoRepository;
    private final UtenteRepository utenteRepository;
    private final TipoRepository tipoRepository;

    private static final Logger logger = LoggerFactory.getLogger(InitService.class);
    private static final String JSON_FILE = "startup-data.json";
    private final PasswordEncoder passwordEncoder;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Transactional
    public void refreshDatabase() {
        dumpDatabase();
        initialize();
    }

    public void dumpDatabase() {
        magazzinoRepository.deleteAll();
        transazioneRepository.deleteAll();
        prodottoRepository.deleteAll();
        utenteRepository.deleteAll();
        tipoRepository.deleteAll();
    }

    public void initialize() {
        try {
            ClassPathResource resource = new ClassPathResource(JSON_FILE);
            InputStream inputStream = resource.getInputStream();
            JsonNode root = objectMapper.readTree(inputStream);

            loadUtenti(root.get("utenti"));

            loadTipi(root.get("tipi"));

            loadMagazzini(root.get("magazzini"));

            loadProdotti(root.get("prodotti"));

            logger.info("Inizializzazione completata con successo.");

        } catch (IOException e) {
            logger.error("Errore critico lettura JSON", e);
        }
    }

    private void loadUtenti(JsonNode nodes) {
        if (nodes == null) return;
        for (JsonNode node : nodes) {
            Utente u = new Utente();
            u.setUsername(node.get("username").asText());
            u.setNome(node.get("nome").asText());
            u.setCognome(node.get("cognome").asText());
            u.setCodFiscale(node.get("codFiscale").asText());
            u.setTelefono(node.get("telefono").asText());
            u.setPassword(passwordEncoder.encode(node.get("password").asText()));
            u.setEmail(node.get("email").asText());

            if (node.has("dataNascita")) {
                u.setDataNascita(LocalDate.parse(node.get("dataNascita").asText()));
            }

            utenteRepository.save(u);
        }
        logger.info("Salvati {} utenti", nodes.size());
    }

    private void loadTipi(JsonNode nodes) {
        if (nodes == null) return;
        for (JsonNode node : nodes) {
            Tipo t = new Tipo();
            t.setNome(node.get("nome").asText());
            tipoRepository.save(t);
        }
        logger.info("Salvati {} tipi", nodes.size());
    }

    private void loadMagazzini(JsonNode nodes) {
        if (nodes == null) return;
        for (JsonNode node : nodes) {
            Magazzino m = new Magazzino();
            m.setNome(node.get("nome").asText());
            m.setIndirizzo(node.get("indirizzo").asText());


            long userId = node.get("utente").get("id").asLong();
            Optional<Utente> utente = utenteRepository.findById(userId);

            utente.ifPresent(m::setUtente);

            magazzinoRepository.save(m);
        }
        logger.info("Salvati {} magazzini", nodes.size());
    }

    private void loadProdotti(JsonNode nodes) {
        if (nodes == null) return;
        for (JsonNode node : nodes) {
            Prodotto p = new Prodotto();
            p.setCodiceSku(node.get("codiceSku").asText());
            p.setNome(node.get("nome").asText());
            p.setDescrizione(node.get("descrizione").asText());
            p.setQuantita(node.get("quantita").asInt());
            p.setPrezzo(node.get("prezzo").asDouble());

            long tipoId = node.get("tipo").get("id").asLong();
            tipoRepository.findById(tipoId).ifPresent(p::setTipo);

            long magId = node.get("magazzino").get("id").asLong();
            magazzinoRepository.findById(magId).ifPresent(p::setMagazzino);

            prodottoRepository.save(p);
        }
        logger.info("Salvati {} prodotti", nodes.size());
    }
}
