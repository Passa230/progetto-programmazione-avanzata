package it.unipi.inventorymanager.services;

import it.unipi.inventorymanager.dtos.MagazzinoRequest;
import it.unipi.inventorymanager.entities.Magazzino;
import it.unipi.inventorymanager.entities.Prodotto;
import it.unipi.inventorymanager.entities.Utente;
import it.unipi.inventorymanager.repositories.MagazzinoRepository;
import it.unipi.inventorymanager.repositories.ProdottoRepository;
import it.unipi.inventorymanager.repositories.UtenteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MagazzinoService {
    @Autowired
    private final MagazzinoRepository repository;
    @Autowired
    private final UtenteRepository utenteRepository;
    @Autowired
    private final ProdottoRepository prodottoRepository;

    @Transactional
    public Magazzino salvaNuovoMagazzino(MagazzinoRequest dto) {
        Magazzino m = new Magazzino();
        m.setNome(dto.getNome());
        m.setIndirizzo(dto.getIndirizzo());
        m.setUtente(utenteRepository.getReferenceById(dto.getUtenteId()));

        System.out.println("Aggiunta del magazzino dell'utente: " + dto.getUtenteId());

        return repository.save(m);
    }

    @Transactional
    public void eliminaMagazzino(Long magazzinoId) {
        Magazzino magazzino = repository.findById(magazzinoId).get();

        List<Prodotto> p = prodottoRepository.findByMagazzinoId(magazzinoId);

        if (!p.isEmpty()) {
            prodottoRepository.deleteAll(p);
        }

        repository.delete(magazzino);
    }

}
