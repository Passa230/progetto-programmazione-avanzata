package it.unipi.inventorymanager.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(
        name = "prodotti",
        uniqueConstraints = {
            @UniqueConstraint(columnNames = {"codice_sku", "magazzino_id"})
        })
@Data @NoArgsConstructor @AllArgsConstructor
public class Prodotto implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(nullable = false, unique = true, name = "codice_sku")
    private String codiceSku;

    @Column(nullable = false)
    private String nome;

    private String descrizione;

    private Integer quantita;

    @Column(nullable = false)
    private Double prezzo;

    @ManyToOne
    @JoinColumn(name = "tipo_id")
    private Tipo tipo;

    @ManyToOne
    @JoinColumn(name = "magazzino_id", nullable = false)
    private Magazzino magazzino;

}
