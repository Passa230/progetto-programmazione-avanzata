package it.unipi.inventorymanager.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MagazzinoRequest {
    private String nome;
    private String indirizzo;
    private Long utenteId;
}
