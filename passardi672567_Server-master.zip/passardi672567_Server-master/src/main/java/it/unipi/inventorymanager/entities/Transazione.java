package it.unipi.inventorymanager.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity @Table(name = "transazioni")
@Data @NoArgsConstructor @AllArgsConstructor
public class Transazione implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne
    @JoinColumn(name = "prodotto_id", nullable = false)
    private Prodotto prodotto;

    @ManyToOne
    @JoinColumn(name = "magazzino_da_id")
    private Magazzino magazzinoDa;

    @ManyToOne
    @JoinColumn(name = "magazzino_a_id")
    private Magazzino magazzinoA;

    @Column(name = "data_movimento")
    private LocalDateTime dataMovimento = LocalDateTime.now();
}
