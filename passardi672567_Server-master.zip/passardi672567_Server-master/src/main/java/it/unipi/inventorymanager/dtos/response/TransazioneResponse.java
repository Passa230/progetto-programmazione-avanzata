package it.unipi.inventorymanager.dtos.response;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransazioneResponse {
    private long id;

    private String nomeProdotto;

    private String nomeMagazzinoDa;
    private String nomeMagazzinoA;

    private LocalDateTime dataMovimento;

}
