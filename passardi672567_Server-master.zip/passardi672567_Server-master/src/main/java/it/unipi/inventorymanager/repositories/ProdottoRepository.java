package it.unipi.inventorymanager.repositories;

import it.unipi.inventorymanager.entities.Prodotto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProdottoRepository extends JpaRepository<Prodotto,Long> {
    List<Prodotto> findByCodiceSku(String codiceSku);

    List<Prodotto> findByTipoId(Long tipoId);

    List<Prodotto> findByMagazzinoId(Long magazzinoId);

    List<Prodotto> findByMagazzino_Utente_IdAndNomeContainingIgnoreCase(Long userId, String nome);

    List<Prodotto> findByMagazzino_Utente_IdAndDescrizioneContainingIgnoreCase(Long userId, String descrizione);

    List<Prodotto> findByMagazzino_Utente_Id(Long userId);
}
