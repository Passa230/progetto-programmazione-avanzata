package it.unipi.inventorymanager.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProdottoRequest {
    private Long id;
    private String nome;
    private String codiceSku;
    private int quantita;
    private double prezzo;
    private String descrizione;
    private Long magazzinoId;
    private String nomeTipo;

}
