package it.unipi.inventorymanager.services;

import it.unipi.inventorymanager.dtos.SearchTransactionRequest;
import it.unipi.inventorymanager.dtos.TransazioneRequest;
import it.unipi.inventorymanager.dtos.response.TransazioneResponse;
import it.unipi.inventorymanager.entities.Magazzino;
import it.unipi.inventorymanager.entities.Prodotto;
import it.unipi.inventorymanager.entities.Transazione;
import it.unipi.inventorymanager.repositories.MagazzinoRepository;
import it.unipi.inventorymanager.repositories.ProdottoRepository;
import it.unipi.inventorymanager.repositories.TransazioneRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TransazioneService {
    @Autowired
    private final TransazioneRepository transazioneRepository;

    @Autowired
    private final MagazzinoRepository magazzinoRepository;

    @Autowired
    private final ProdottoRepository prodottoRepository;


    public Transazione createTransazione(TransazioneRequest transazione) {
        Transazione t = new Transazione();

        t.setDataMovimento(transazione.getDataMovimento());



        Optional<Magazzino> mA = magazzinoRepository.findById(transazione.getMagazzinoAId());
        if (mA.isPresent()) {
            t.setMagazzinoA(mA.get());
        }

        if(transazione.getMagazzinoDaId() == null) {
            System.out.println("NULLO");
        }

        Optional<Magazzino> mDa = magazzinoRepository.findById(transazione.getMagazzinoDaId());
        if(mDa.isPresent()) {
            t.setMagazzinoDa(mDa.get());
        }

        Optional<Prodotto> p = prodottoRepository.findById(transazione.getProdottoId());
        if(p.isPresent()) {
            t.setProdotto(p.get());
        }

        p.get().setMagazzino(mA.get());
        prodottoRepository.save(p.get());

        return transazioneRepository.save(t);
    }

    public List<TransazioneResponse> findByUserFilter(SearchTransactionRequest request) {

        List<Transazione> transazioni = transazioneRepository.cercaConFiltri(request.getMagazzinoPartenza(), request.getMagazzinoDestinazione(), request.getText());

        List<TransazioneResponse> transazioneResponse = new ArrayList<>();
        for(Transazione t : transazioni) {
            TransazioneResponse tmp = new TransazioneResponse();
            tmp.setDataMovimento(t.getDataMovimento());
            tmp.setId(t.getId());
            tmp.setNomeProdotto(t.getProdotto().getNome());
            tmp.setNomeMagazzinoDa(t.getMagazzinoDa().getNome());
            tmp.setNomeMagazzinoA(t.getMagazzinoA().getNome());
            transazioneResponse.add(tmp);
        }

        return transazioneResponse;
    }
}
