package it.unipi.inventorymanager.repositories;

import it.unipi.inventorymanager.entities.Magazzino;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MagazzinoRepository extends JpaRepository<Magazzino,Long> {
    List<Magazzino> findByUtenteId(Long utenteId);

}
