# V1__crea_schema_iniziale.sql

CREATE TABLE tipi (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE
);

create table Utenti (
	id BIGINT AUTO_INCREMENT PRIMARY KEY,
    
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    
	CodFiscale varchar(17),   
    nome VARCHAR(100) NOT NULL,    
    cognome VARCHAR(100) NOT NULL,  
    codice_fiscale VARCHAR(16) UNIQUE NOT NULL,
    data_nascita DATE, 
    email VARCHAR(100) UNIQUE,
    telefono VARCHAR(20),
    
    ruolo varchar(20) NOT NULL default 'ROLE_USER'
);

CREATE TABLE magazzini (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    indirizzo VARCHAR(255),		-- Indirizzo del magazzino (Possibile variazione --> suddividere l'indirizzo nelle sue componenti)
    utente_id BIGINT,			-- Utente creatore del magazzino
    CONSTRAINT fk_magazzino_utente FOREIGN KEY (utente_id) REFERENCES utenti(id)
);

CREATE TABLE prodotti (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    codice_sku VARCHAR(50) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    descrizione TEXT,
    prezzo DECIMAL(10,2),
    tipo_id BIGINT,
    magazzino_id BIGINT NOT NULL,
    quantita INT NOT NULL DEFAULT 0,

    CONSTRAINT fk_prodotto_tipo FOREIGN KEY (tipo_id) REFERENCES tipi(id),
    CONSTRAINT fk_prodotto_magazzino FOREIGN KEY (magazzino_id) REFERENCES magazzini(id) ON DELETE CASCADE,
    CONSTRAINT uq_sku_per_magazzino UNIQUE (codice_sku, magazzino_id)
);