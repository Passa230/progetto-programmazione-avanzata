# V2__crea_storico_transazioni.sql

CREATE TABLE transazioni (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    prodotto_id BIGINT NOT NULL,
    magazzino_da_id BIGINT,
    magazzino_a_id BIGINT,
    data_movimento TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_trans_prodotto FOREIGN KEY (prodotto_id) REFERENCES prodotti(id),
    CONSTRAINT fk_trans_magazzino_da FOREIGN KEY (magazzino_da_id) REFERENCES magazzini(id),
    CONSTRAINT fk_trans_magazzino_a FOREIGN KEY (magazzino_a_id) REFERENCES magazzini(id)
);