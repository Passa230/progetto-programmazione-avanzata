-- V3__insert_tipi.sql

INSERT INTO tipi (nome) VALUES ('Elettronica');
INSERT INTO tipi (nome) VALUES ('Informatica');
INSERT INTO tipi (nome) VALUES ('Cancelleria');
INSERT INTO tipi (nome) VALUES ('Arredamento');
INSERT INTO tipi (nome) VALUES ('Smartphone');