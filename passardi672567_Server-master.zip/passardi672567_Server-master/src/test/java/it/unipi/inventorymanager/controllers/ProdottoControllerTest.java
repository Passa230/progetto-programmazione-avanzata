package it.unipi.inventorymanager.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.unipi.inventorymanager.dtos.ProdottoRequest;
import it.unipi.inventorymanager.dtos.RicercaRequest;
import it.unipi.inventorymanager.dtos.response.ProdottoResponse;
import it.unipi.inventorymanager.entities.Prodotto;
import it.unipi.inventorymanager.services.ProdottoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class ProdottoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private ObjectMapper objectMapper = new ObjectMapper();

    @MockitoBean
    private ProdottoService prodottoService;


    @Test
    void testCreaProdotto() throws Exception {
        ProdottoRequest request = new ProdottoRequest();
        request.setNome("Nuovo Martello");
        request.setPrezzo(15.50);
        request.setMagazzinoId(1L);

        Prodotto prodottoSalvato = new Prodotto();
        prodottoSalvato.setId(100L);
        prodottoSalvato.setNome("Nuovo Martello");

        when(prodottoService.creaProdotto(any(ProdottoRequest.class)))
                .thenReturn(prodottoSalvato);

        mockMvc.perform(post("/api/prodotti/crea")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(100))
                .andExpect(jsonPath("$.nome").value("Nuovo Martello"));
    }

    @Test
    void cercaProdotti() throws Exception {
        RicercaRequest request = new RicercaRequest();
        request.setUserId(1L);
        request.setTesto("Trapano");
        request.setNomeFiltro("generico");

        ProdottoResponse response = new ProdottoResponse();
        response.setId(55L);
        response.setNome("Trapano Bosch");
        response.setPrezzo(99.99);

        when(prodottoService.cercaProdotto(any(RicercaRequest.class)))
                .thenReturn(List.of(response));

        mockMvc.perform(post("/api/prodotti/cerca")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].nome").value("Trapano Bosch"))
                .andExpect(jsonPath("$[0].prezzo").value(99.99));
    }

    @Test
    void getProdottiByUserId() throws Exception {
        Long userId = 1L;

        ProdottoResponse p1 = new ProdottoResponse();
        p1.setNome("Oggetto A");
        p1.setNomeMagazzino("Garage");

        when(prodottoService.findProdottiByUserId(userId))
                .thenReturn(List.of(p1));

        mockMvc.perform(get("/api/prodotti/all/{id}", userId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nome").value("Oggetto A"))
                .andExpect(jsonPath("$[0].nomeMagazzino").value("Garage"));
    }
}