package it.unipi.inventorymanager.services;

import it.unipi.inventorymanager.dtos.ProdottoRequest;
import it.unipi.inventorymanager.dtos.RicercaRequest;
import it.unipi.inventorymanager.dtos.response.ProdottoResponse;
import it.unipi.inventorymanager.entities.Magazzino;
import it.unipi.inventorymanager.entities.Prodotto;
import it.unipi.inventorymanager.entities.Tipo;
import it.unipi.inventorymanager.entities.Utente;
import it.unipi.inventorymanager.repositories.MagazzinoRepository;
import it.unipi.inventorymanager.repositories.ProdottoRepository;
import it.unipi.inventorymanager.repositories.TipoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProdottoServiceTest {

    @Mock
    private ProdottoRepository prodottoRepository;

    @Mock
    private MagazzinoRepository magazzinoRepository;

    @Mock
    private TipoRepository tipoRepository;

    @InjectMocks
    private ProdottoService prodottoService;

    private Prodotto creaProdottoFinto(Long id, String nome, Long userId) {
        Prodotto p = new Prodotto();
        p.setId(id);
        p.setNome(nome);
        p.setPrezzo(10.0);
        p.setQuantita(5);
        p.setCodiceSku("SKU-" + id);
        p.setDescrizione("Descrizione test");

        // Creo le dipendenze per evitare NullPointerException nel mapping
        Tipo tipo = new Tipo();
        tipo.setId(1L);
        tipo.setNome("Elettronica");
        p.setTipo(tipo);

        Magazzino mag = new Magazzino();
        mag.setId(10L);
        mag.setNome("Magazzino Test");

        Utente u = new Utente();
        u.setId(userId);
        mag.setUtente(u);

        p.setMagazzino(mag);

        return p;
    }

    private ProdottoRequest creaRequestFinta(String nome, double prezzo) {
        ProdottoRequest req = new ProdottoRequest();
        req.setNome(nome);
        req.setPrezzo(prezzo);
        req.setCodiceSku("SKU-TEST");
        req.setMagazzinoId(1L);
        return req;
    }

    @Test
    void findProdottiByMagazzinoId() {
        Long magazzinoId = 10L;
        List<Prodotto> listaMock = List.of(creaProdottoFinto(1L, "Martello", 1L));
        when(prodottoRepository.findByMagazzinoId(magazzinoId)).thenReturn(listaMock);

        var risultato = prodottoService.findProdottiByMagazzinoId(magazzinoId);

        assertNotNull(risultato);
        assertFalse(risultato.isEmpty());
        assertEquals(1, risultato.size());
        assertEquals("Martello", risultato.get(0).getNome());

        verify(prodottoRepository, times(1)).findByMagazzinoId(magazzinoId);
    }

    @Test
    void creaProdotto() {
        ProdottoRequest inputRequest = creaRequestFinta("Nuovo Prodotto", 10.0);
        Prodotto salvatoDalDb = creaProdottoFinto(55L, "Nuovo Prodotto", 1L);

        Magazzino magazzinoFinto = new Magazzino();
        magazzinoFinto.setId(1L);
        when(magazzinoRepository.findById(1L)).thenReturn(java.util.Optional.of(magazzinoFinto));

        when(prodottoRepository.save(any(Prodotto.class))).thenReturn(salvatoDalDb);
        Prodotto risultato = prodottoService.creaProdotto(inputRequest);
        assertEquals(55L, risultato.getId());
        assertEquals("Nuovo Prodotto", risultato.getNome());
    }

    @Test
    void cercaProdotto() {
        Long userId = 1L;
        String keyword = "Trapano";

        RicercaRequest request = new RicercaRequest();
        request.setUserId(userId);
        request.setTesto(keyword);
        request.setNomeFiltro("generico");

        List<Prodotto> listaMock = List.of(
                creaProdottoFinto(55L, "Trapano Bosch", userId)
        );

        when(prodottoRepository.findByMagazzino_Utente_IdAndNomeContainingIgnoreCase(userId, keyword))
                .thenReturn(listaMock);

        List<ProdottoResponse> risultato = prodottoService.cercaProdotto(request);

        assertEquals(1, risultato.size());
        assertEquals("Trapano Bosch", risultato.get(0).getNome());
    }

    @Test
    void findProdottiByUserId() {
        Long userId = 1L;

        Magazzino magazzinoFinto = new Magazzino();
        magazzinoFinto.setId(10L);
        magazzinoFinto.setNome("Garage");
        Utente u = new Utente();
        u.setId(userId);
        magazzinoFinto.setUtente(u);

        Prodotto prodottoFinto = creaProdottoFinto(50L, "Martello", userId);
        prodottoFinto.setMagazzino(magazzinoFinto);

        when(magazzinoRepository.findByUtenteId(userId)).thenReturn(List.of(magazzinoFinto));

        when(prodottoRepository.findByMagazzinoId(magazzinoFinto.getId())).thenReturn(List.of(prodottoFinto));

        List<ProdottoResponse> risultato = prodottoService.findProdottiByUserId(userId);

        assertNotNull(risultato);
        assertEquals(1, risultato.size());
        assertEquals("Martello", risultato.get(0).getNome());
        assertEquals("Garage", risultato.get(0).getNomeMagazzino());

        verify(magazzinoRepository).findByUtenteId(userId);
        verify(prodottoRepository).findByMagazzinoId(magazzinoFinto.getId());
    }
}