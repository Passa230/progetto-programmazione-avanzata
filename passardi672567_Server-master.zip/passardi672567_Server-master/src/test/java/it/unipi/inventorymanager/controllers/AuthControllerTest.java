package it.unipi.inventorymanager.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import it.unipi.inventorymanager.dtos.LoginRequest;
import it.unipi.inventorymanager.dtos.RegisterRequest;
import it.unipi.inventorymanager.entities.Utente;
import it.unipi.inventorymanager.services.AuthService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private ObjectMapper objectMapper = new ObjectMapper();

    @MockitoBean // (Usa @MockBean se @MockitoBean ti dà errore)
    private AuthService authService;

    @Test
    void login() throws Exception {

        LoginRequest loginOk = new LoginRequest();
        loginOk.setUsername("admin");
        loginOk.setPassword("password123");


        Utente utenteTrovato = new Utente();
        utenteTrovato.setId(1L);
        utenteTrovato.setUsername("admin");
        utenteTrovato.setRuolo("ADMIN");


        when(authService.autentica("admin", "password123")).thenReturn(true);
        when(authService.findByUsername("admin")).thenReturn(utenteTrovato);

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginOk)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("admin"))
                .andExpect(jsonPath("$.ruolo").value("ADMIN"));


        // Password sbagliata
        LoginRequest loginKo = new LoginRequest();
        loginKo.setUsername("hacker");
        loginKo.setPassword("sbagliata");

        when(authService.autentica("hacker", "sbagliata")).thenReturn(false);

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginKo)))
                .andExpect(status().isUnauthorized())
                .andExpect(content().string("Errore"));
    }

    @Test
    void register() throws Exception {

        RegisterRequest regOk = new RegisterRequest();
        regOk.setUsername("nuovoUtente");
        regOk.setPassword("pass");

        when(authService.registra(any(RegisterRequest.class))).thenReturn(true);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(regOk)))
                .andExpect(status().isOk())
                .andExpect(content().string("Registrato"));


        // Utente giù esistente
        RegisterRequest regKo = new RegisterRequest();
        regKo.setUsername("giaEsistente");


        when(authService.registra(argThat(req -> "giaEsistente".equals(req.getUsername()))))
                .thenReturn(false);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(regKo)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Username già esistente"));
    }
}