package it.unipi.inventorymanager.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.unipi.inventorymanager.dtos.MagazzinoRequest;
import it.unipi.inventorymanager.entities.Magazzino;
import it.unipi.inventorymanager.repositories.MagazzinoRepository;
import it.unipi.inventorymanager.services.MagazzinoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class MagazzinoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private ObjectMapper objectMapper = new ObjectMapper();

    @MockitoBean
    private MagazzinoRepository magazzinoRepository;

    @MockitoBean
    private MagazzinoService magazzinoService;

    @Test
    void getMagazzini() throws Exception {
        Long userId = 1L;

        Magazzino m = new Magazzino();
        m.setId(10L);
        m.setNome("Magazzino Test");
        m.setIndirizzo("Via Roma 1");

        when(magazzinoRepository.findByUtenteId(userId)).thenReturn(List.of(m));

        mockMvc.perform(get("/api/magazzini/utente/{id}", userId) // Chiama l'URL vero
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()) // Si aspetta 200 OK
                .andExpect(jsonPath("$.size()").value(1)) // Lista di 1 elemento
                .andExpect(jsonPath("$[0].nome").value("Magazzino Test"))
                .andExpect(jsonPath("$[0].indirizzo").value("Via Roma 1"));
    }

    @Test
    void creaMagazzino() throws Exception {
        MagazzinoRequest request = new MagazzinoRequest();
        request.setNome("Nuovo Deposito");
        request.setIndirizzo("Via Milano 2");
        request.setUtenteId(1L);

        Magazzino salvato = new Magazzino();
        salvato.setId(55L);
        salvato.setNome("Nuovo Deposito");

        when(magazzinoService.salvaNuovoMagazzino(any(MagazzinoRequest.class)))
                .thenReturn(salvato);

        mockMvc.perform(post("/api/magazzini/crea")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(55))
                .andExpect(jsonPath("$.nome").value("Nuovo Deposito"));
    }
}