package org.example.inventorymanagerclient;

import com.google.gson.Gson;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import org.example.inventorymanagerclient.dtos.MagazzinoDTO;
import org.example.inventorymanagerclient.models.UserSession;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class NuovoMagazzinoController extends BaseController{
    @FXML
    private TextField nomeField;
    @FXML
    private TextField indirizzoField;

    @FXML
    private void handleSave() {
        String nome = nomeField.getText();
        String indirizzo = indirizzoField.getText();

        if (nome.isEmpty() || indirizzo.isEmpty()) {
            showAlert("Errore", "Tutti i campi sono obbligatori.", Alert.AlertType.ERROR);
            return;
        }

        UserSession u = UserSession.getInstance();
        MagazzinoDTO magazzinoDTO = new MagazzinoDTO();
        magazzinoDTO.setNome(nome);
        magazzinoDTO.setIndirizzo(indirizzo);
        magazzinoDTO.setUtenteId(u.getId());

        Gson gson = new Gson();
        String json = gson.toJson(magazzinoDTO);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/magazzini/crea"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();


        HttpClient client = HttpClient.newHttpClient();

        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        if (response.statusCode() == 200 || response.statusCode() == 201) {
                            //showAlert("Successo", "Magazzino creato correttamente!", Alert.AlertType.INFORMATION);
                            try {
                                HelloApplication.setRoot("magazzino-view-page");
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        } else {
                            showAlert("Errore Server", "Codice errore: " + response.statusCode(), Alert.AlertType.ERROR);
                        }
                    });
                })
                .exceptionally(ex -> {
                    Platform.runLater(() -> {
                        showAlert("Errore di Rete", "Connessione fallita: " + ex.getMessage(), Alert.AlertType.ERROR);
                    });
                    return null;
                });
    }

    private void showAlert(String titolo, String contenuto, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titolo);
        alert.setHeaderText(null);
        alert.setContentText(contenuto);
        alert.showAndWait();
    }
}
