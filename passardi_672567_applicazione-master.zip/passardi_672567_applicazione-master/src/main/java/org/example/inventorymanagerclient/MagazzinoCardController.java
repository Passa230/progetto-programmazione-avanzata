package org.example.inventorymanagerclient;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.text.Text;
import org.example.inventorymanagerclient.dtos.MagazzinoDTO;
import org.example.inventorymanagerclient.models.MagazzinoSession;
import org.example.inventorymanagerclient.models.UserSession;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.List;

public class MagazzinoCardController extends BaseController {

    @FXML
    private Text nomeText;
    @FXML
    private Label indirizzoLabel;


    private MagazzinoDTO magazzinoSession;

    public void setData(MagazzinoDTO m) {
        magazzinoSession = m;
        nomeText.setText(m.getNome());
        indirizzoLabel.setText(m.getIndirizzo());
    }


    @FXML
    private void handleViewProducts() throws IOException {
        MagazzinoSession mss = MagazzinoSession.getInstance();

        Long idDaPassare = this.magazzinoSession.getId();
        String name =  this.magazzinoSession.getNome();
        String address = this.magazzinoSession.getIndirizzo();

        mss.setId(idDaPassare);
        mss.setName(name);
        mss.setAddress(address);

        HelloApplication.setRoot("prodotti-per-magazzino-list-page");
    }

    @FXML
    private void handleDelete() throws IOException {
        Long mss = this.magazzinoSession.getId();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/magazzini/elimina/" + mss))
                .header("Accept", "application/json")
                .DELETE()
                .build();

        HttpClient.newHttpClient()
                .sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {
                        Platform.runLater(() -> {
                            mostraAlert("Successo!", "Eliminazione avvenuta con successo", "Il magazzino è stato eliminato con successo", Alert.AlertType.CONFIRMATION);
                        });
                    } else {
                        System.out.println("Errore: " + response.statusCode() + ": " + response.body());
                    }
                })
                .exceptionally(ex -> {
                    ex.printStackTrace();
                    return null;
                });

        openAccountSettings();
    }
}
