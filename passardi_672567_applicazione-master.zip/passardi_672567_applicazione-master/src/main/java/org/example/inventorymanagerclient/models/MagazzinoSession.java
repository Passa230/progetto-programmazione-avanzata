package org.example.inventorymanagerclient.models;

public class MagazzinoSession {
    private static MagazzinoSession instance;
    private Long id;
    private String name;
    private String address;

    public MagazzinoSession() {}

    public static MagazzinoSession getInstance() {
        if (instance == null) {
            instance = new MagazzinoSession();
        }
        return instance;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
