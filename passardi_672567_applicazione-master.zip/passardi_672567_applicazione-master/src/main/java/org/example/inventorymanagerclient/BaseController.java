package org.example.inventorymanagerclient;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;

import java.io.IOException;

public abstract class BaseController {
    @FXML
    protected void backToHome() throws IOException {
        HelloApplication.setRoot("magazzino-view-page");
    }

    @FXML protected void openAccountSettings() throws IOException {
        HelloApplication.setRoot("profile-view-page");
    }
    @FXML protected void showRecentLogs() throws IOException {
        HelloApplication.setRoot("transaction-table-page");
    }
    @FXML protected void openAdvancedSearch() throws IOException {
        HelloApplication.setRoot("research-product-page");
    }

    void mostraAlert(String titolo, String header, String contenuto, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titolo);
        alert.setHeaderText(header);
        alert.setContentText(contenuto);
        alert.showAndWait();
    }
}
