package org.example.inventorymanagerclient.models;

public class Prodotto {
    private Long id;
    private String nome;
    private String codiceSku;
    private String nomeTipo;
    private Double prezzo;
    private Integer quantita;
    private String nomeMagazzino;
    private String descrizione;

    public Prodotto(String nome, String codiceSku, String tipoNome, Double prezzo, Integer quantita, String nomeMagazzino,  Long IdProdotto, String descrizione) {
        this.nome = nome;
        this.codiceSku = codiceSku;
        this.nomeTipo = tipoNome;
        this.prezzo = prezzo;
        this.quantita = quantita;
        this.nomeMagazzino = nomeMagazzino;
        this.id = IdProdotto;
        this.descrizione = descrizione;
    }

    public String getNome() { return nome; }
    public String getCodiceSku() { return codiceSku; }
    public String getNomeTipo() { return nomeTipo; }
    public Double getPrezzo() { return prezzo; }
    public String getNomeMagazzino() { return nomeMagazzino; }
    public void setNomeMagazzino(String nomeMagazzino) { this.nomeMagazzino = nomeMagazzino; }

    public Long getId() {
        return id;
    }

    public Integer getQuantita() {
        return quantita;
    }

    public String getDescrizione() {
        return descrizione;
    }

    @Override
    public String toString() {
        return this.nome + " (" + this.codiceSku + ")";
    }
}
