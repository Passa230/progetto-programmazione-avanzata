package org.example.inventorymanagerclient;

import com.google.gson.Gson;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import org.example.inventorymanagerclient.dtos.UtenteDTO;
import org.example.inventorymanagerclient.models.Prodotto;
import org.example.inventorymanagerclient.models.UserSession;
import org.example.inventorymanagerclient.requests.LoginRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;

public class LoginController extends BaseController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

    @FXML
    private void handleLogin(ActionEvent event) throws IOException {
        String email = usernameField.getText();
        String password = passwordField.getText();

        // Utilizzo di un alert nel caso in cui i campi siano vuoti
        if (email.isEmpty() || password.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Errore: Credenziali non valide");
            alert.setHeaderText("Errore: Credenziali vuote");
            alert.setContentText("I campi sono vuoti, non è possibile procedere con il login");

            alert.showAndWait();
            return;
        }

        Gson gson = new Gson();
        LoginRequest loginRequest = new LoginRequest(email, password);
        String json = gson.toJson(loginRequest);

        HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create("http://127.0.0.1:8080/auth/login"))
                                .header("Content-Type", "application/json")
                                        .POST(HttpRequest.BodyPublishers.ofString(json))
                                                .build();
        HttpClient client = HttpClient.newHttpClient();
        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                        .thenAccept(response -> {
                            if(response.statusCode() == 200) {
                                UserSession session = UserSession.getInstance();

                                String jsonResponse = response.body();
                                UtenteDTO utenteLoggato = gson.fromJson(jsonResponse, UtenteDTO.class);

                                UserSession sessione = UserSession.getInstance();
                                sessione.setId(utenteLoggato.getId());
                                sessione.setUsername(utenteLoggato.getUsername());
                                sessione.setNome(utenteLoggato.getNome());
                                sessione.setCognome(utenteLoggato.getCognome());
                                sessione.setRuolo(utenteLoggato.getRuolo());
                                sessione.setEmail(utenteLoggato.getEmail());
                                sessione.setTelefono(utenteLoggato.getTelefono());
                                sessione.setCodFiscale(utenteLoggato.getCodFiscale());
                                sessione.setDataNascita(utenteLoggato.getDataNascita());
                                javafx.application.Platform.runLater(() -> {
                                    try {
                                        HelloApplication.setRoot("magazzino-view-page");
                                    } catch (IOException e) {
                                        logger.error(e.getMessage());
                                    }
                                });
                            } else  {
                                String messaggioServer = response.body();
                                logger.warn("Autenticazione fallita: {}", messaggioServer);
                                javafx.application.Platform.runLater(() -> {
                                    mostraAlert("Errore", "Credenziali non valide", "Email o password errati");
                                });
                            }
                        }).exceptionally(ex -> {
                            logger.error("[ERRORE]: Server irraggiungibile: " +  ex.getMessage());
                            javafx.application.Platform.runLater(() -> {
                                mostraAlert("Errore di connessione", "Server irraggiungibile", "Assicurati che il servizio Spring sia attivo.");
                            });
                            return null;
                        });


    }

    private void mostraAlert(String titolo, String header, String contenuto) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titolo);
        alert.setHeaderText(header);
        alert.setContentText(contenuto);
        alert.showAndWait();
    }

    @FXML
    private void handleRegister(ActionEvent event) throws IOException {
        HelloApplication.setRoot("register-page");
    }

    @FXML
    private void initService() {
        String url = "http://localhost:8080/init/";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpClient.newHttpClient()
                .sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {
                        Platform.runLater(() -> {

                            mostraAlert("Successo!", "Inizializzazione avvenuta con successo", "I dati sono stato registrati correttamente, è possibile avviare il servizio", Alert.AlertType.CONFIRMATION);
                        });
                    } else {
                        Platform.runLater(() ->
                                mostraAlert("Errore!", "Errore del server: " + response.statusCode(), "Errore nel caricamento del prodotti, riprovare più tardi, " + response.body(), Alert.AlertType.ERROR)
                        );
                    }
                })
                .exceptionally(ex -> {
                    Platform.runLater(() ->
                            mostraAlert("Errore!", "Errore di rete!", ex.getMessage(),  Alert.AlertType.ERROR)
                    );
                    return null;
                });
    }
}