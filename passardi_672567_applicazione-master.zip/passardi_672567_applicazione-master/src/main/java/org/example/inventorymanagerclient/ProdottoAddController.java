package org.example.inventorymanagerclient;

import com.google.gson.Gson;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.example.inventorymanagerclient.dtos.TipoDTO;
import org.example.inventorymanagerclient.models.MagazzinoSession;
import org.example.inventorymanagerclient.models.UserSession;
import org.example.inventorymanagerclient.requests.ProdottoRequest;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class ProdottoAddController extends BaseController {

    @FXML private TextField nomeField;
    @FXML private TextField skuField;
    @FXML private TextField prezzoField;
    @FXML private TextField quantitaField;
    @FXML private TextArea descrizioneField;
    @FXML private ComboBox<String> tipoComboBox;

    @FXML
    public void initialize() {
        Gson gson = new Gson();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/tipi"))
                .GET()
                .build();
        HttpClient.newHttpClient().sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {
                        TipoDTO[] tipiScaricati = gson.fromJson(response.body(), TipoDTO[].class);

                        Platform.runLater(() -> {
                            tipoComboBox.getItems().clear(); // Pulisce vecchi dati

                            if (tipiScaricati != null) {
                                for (TipoDTO t : tipiScaricati) {
                                    tipoComboBox.getItems().add(t.getNome());
                                }
                            }
                        });
                    } else {
                        Platform.runLater(() ->
                                System.out.println("Errore caricamento tipi: " + response.statusCode())
                        );
                    }
                })
                .exceptionally(ex -> {
                    ex.printStackTrace();
                    return null;
                });

    }

    @FXML
    private void saveProdotto() {
        if (nomeField.getText().isEmpty() || skuField.getText().isEmpty() || prezzoField.getText().isEmpty()) {
            mostraAlert("Errore di compilazione", "Errore nella compilazione dei campi", "Compilare tutti i campi necessari prima di poter procedere con la creazione del prodotto", Alert.AlertType.WARNING);
            return;
        }

        try {
            double prezzo = Double.parseDouble(prezzoField.getText().replace(",", "."));
            int quantita = Integer.parseInt(quantitaField.getText());
            Long magazzinoId = MagazzinoSession.getInstance().getId();

            ProdottoRequest requestPayload = new ProdottoRequest(
                    nomeField.getText(),
                    skuField.getText(),
                    descrizioneField.getText(),
                    quantita,
                    prezzo,
                    magazzinoId,
                    tipoComboBox.getValue()
            );

            inviaDatiAlServer(requestPayload);

        } catch (NumberFormatException e) {
            mostraAlert("Errore Formato", "Errore nel formato del prezzo.", "Il prezzo deve essere scritto utilizzando la notazione x,yz, mentre la quantità deve essere un numero intero", Alert.AlertType.WARNING);
        }
    }

    private void inviaDatiAlServer(ProdottoRequest payload) {
        Gson gson = new Gson();
        String jsonBody = gson.toJson(payload);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/prodotti/crea"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

        HttpClient.newHttpClient().sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        if (response.statusCode() == 200 || response.statusCode() == 201) {
                            mostraAlert("Successo!", "Creazione avvenuta con successo!", "Il prodotto è stato aggiunto con successo, è ora possibile visualizzarlo nell'apposita lista", Alert.AlertType.CONFIRMATION);
                            try {
                                backToHome();
                            } catch (Exception e) { e.printStackTrace(); }
                        } else {
                            mostraAlert("Errore Server", "Codice: " + response.statusCode(), "L'errore è stato causato da: " + response.body(), Alert.AlertType.ERROR);
                        }
                    });
                })
                .exceptionally(ex -> {
                    Platform.runLater(() -> mostraAlert("Errore Rete", "Errore di rete" , ex.getMessage() ,Alert.AlertType.ERROR));
                    return null;
                });
    }
}
