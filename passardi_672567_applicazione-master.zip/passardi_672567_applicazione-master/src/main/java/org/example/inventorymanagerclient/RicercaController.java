package org.example.inventorymanagerclient;

import com.google.gson.Gson;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;

import org.example.inventorymanagerclient.models.Prodotto;
import org.example.inventorymanagerclient.models.UserSession;
import org.example.inventorymanagerclient.requests.RicercaRequest;

public class RicercaController extends BaseController {

    @FXML private TextField searchField;
    @FXML private ComboBox<String> searchTypeCombo;
    @FXML private TableView<Prodotto> resultsTable;
    @FXML private TableColumn<Prodotto, String> colNome;
    @FXML private TableColumn<Prodotto, String> colSku;
    @FXML private TableColumn<Prodotto, String> colTipo;
    @FXML private TableColumn<Prodotto, String> colMagazzino;

    private final ObservableList<Prodotto> searchResults = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        searchTypeCombo.setItems(FXCollections.observableArrayList("Nome", "Codice SKU", "Categoria"));
        searchTypeCombo.getSelectionModel().selectFirst();


        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colSku.setCellValueFactory(new PropertyValueFactory<>("codiceSku"));
        colTipo.setCellValueFactory(new PropertyValueFactory<>("nomeTipo"));
        colMagazzino.setCellValueFactory(new PropertyValueFactory<>("nomeMagazzino"));

        colMagazzino.setText("Magazzino");

        resultsTable.setItems(searchResults);
    }

    @FXML
    private void handleManualSearch() {
        String query = searchField.getText().trim();
        String selectedType = searchTypeCombo.getValue();


        if (query.isEmpty()) {
            mostraAlert("Warning!", "Attenzione ai parametri di ricerca", "Inserire dei parametri di ricerca corretti o non vuoti", Alert.AlertType.WARNING);
            return;
        }

        String filtroServer = switch (selectedType) {
            case "Nome" -> "nome";
            case "Codice SKU" -> "sku";
            case "Categoria" -> "tipo";
            default -> "nome";
        };

        eseguiChiamataServizio(query, filtroServer);
    }

    private void eseguiChiamataServizio(String q, String t) {
        searchResults.clear();
        Gson gson = new Gson();


        RicercaRequest requestBody = new RicercaRequest(q, t, UserSession.getInstance().getId());

        String jsonBody = gson.toJson(requestBody);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/prodotti/cerca"))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

        HttpClient.newHttpClient()
                .sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {

                        Prodotto[] array = gson.fromJson(response.body(), Prodotto[].class);
                        Platform.runLater(() -> {
                            if (array != null && array.length > 0) {
                                searchResults.addAll(Arrays.asList(array));
                            } else {
                                mostraAlert("Information!", "Nessun prodotto trovato.", "Il prodotto non risulta all'interno di nessun magazzino, controllare di aver inserito correttamente i parametri", Alert.AlertType.INFORMATION);
                            }
                        });
                    } else {
                        Platform.runLater(() ->
                                mostraAlert("Errore!", ("Codice di errore: " + response.statusCode()), "Riprovare più tardi", Alert.AlertType.ERROR)
                        );
                    }
                })
                .exceptionally(ex -> {
                    ex.printStackTrace();
                    Platform.runLater(() ->
                            mostraAlert("Errore!", "Errore di rete", "Si è verificato un errore di rete, riprovare più tardi", Alert.AlertType.ERROR)
                    );
                    return null;
                });


    }

}