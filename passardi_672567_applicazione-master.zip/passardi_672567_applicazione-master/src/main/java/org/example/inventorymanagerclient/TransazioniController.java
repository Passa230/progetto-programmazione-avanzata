package org.example.inventorymanagerclient;

import com.google.gson.Gson;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.inventorymanagerclient.dtos.MagazzinoDTO;
import org.example.inventorymanagerclient.models.Prodotto;
import org.example.inventorymanagerclient.models.Transazione;
import org.example.inventorymanagerclient.models.UserSession;
import org.example.inventorymanagerclient.requests.SearchTransactionRequest;
import org.example.inventorymanagerclient.requests.TransazioneRequest;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

public class TransazioniController extends BaseController {

    @FXML private TableView<Transazione> transazioniTable;
    @FXML private TableColumn<Transazione, String> colData;
    @FXML private TableColumn<Transazione, String> colProdotto;
    @FXML private TableColumn<Transazione, String> colDa;
    @FXML private TableColumn<Transazione, String> colA;

    @FXML private ComboBox<MagazzinoDTO> comboPartenza;
    @FXML private ComboBox<MagazzinoDTO> comboDestinazione;
    @FXML private TextField searchField;

    private final ObservableList<Transazione> listaTransazioni = FXCollections.observableArrayList();

    List<MagazzinoDTO> lista;

    @FXML
    public void initialize() {
        colData.setCellValueFactory(new PropertyValueFactory<>("dataFormattata"));
        colProdotto.setCellValueFactory(new PropertyValueFactory<>("nomeProdotto"));
        colDa.setCellValueFactory(new PropertyValueFactory<>("nomeMagazzinoDa"));
        colA.setCellValueFactory(new PropertyValueFactory<>("nomeMagazzinoA"));

        String whiteStyle = "-fx-text-fill: white; -fx-alignment: CENTER;";
        colData.setStyle(whiteStyle);
        colProdotto.setStyle(whiteStyle);
        colDa.setStyle(whiteStyle);
        colA.setStyle(whiteStyle);

        Gson gson = new Gson();
        Long utenteId = UserSession.getInstance().getId();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/magazzini/utente/" + utenteId))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpClient.newHttpClient()
                .sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {
                        MagazzinoDTO[] array = gson.fromJson(response.body(), MagazzinoDTO[].class);
                        lista = Arrays.asList(array);
                        comboDestinazione.getItems().addAll(lista);
                        comboPartenza.getItems().addAll(lista);
                    }
                })
                .exceptionally(ex -> {
                    mostraAlert("Errore!", "Errore del server", "Non è stato possibil recuperare i dati dal server, riprovare più tardi", Alert.AlertType.ERROR);
                    return null;
                });

        transazioniTable.setItems(listaTransazioni);

    }

    @FXML
    private void handleFilter() {
        Gson gson = new Gson();
        Long magazzinoPartenza = (comboPartenza.getValue() != null) ? comboPartenza.getValue().getId() : null;
        Long magazzinoDestinazione = (comboDestinazione.getValue() != null) ? comboDestinazione.getValue().getId() : null;
        String nome = searchField.getText();

        SearchTransactionRequest request = new SearchTransactionRequest(
                magazzinoDestinazione, magazzinoPartenza, nome
        );

        String json = gson.toJson(request);
        HttpRequest request2 = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/transazioni/cerca/"))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpClient.newHttpClient()
                .sendAsync(request2, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {
                        Transazione[] array = gson.fromJson(response.body(), Transazione[].class);

                        Platform.runLater(() -> {
                            listaTransazioni.clear();
                            if (array != null) {
                                listaTransazioni.addAll(Arrays.asList(array));
                            } else {
                                mostraAlert("Attenzione!", "Ricerca vuota", "La ricerca non ha prodotto risultati", Alert.AlertType.WARNING);
                            }
                        });
                    } else {
                        Platform.runLater(() ->
                                mostraAlert("Errore!", "Errore del server", "Impossibile caricare prodotti: " + response.statusCode(), Alert.AlertType.ERROR)
                        );
                    }
                })
                .exceptionally(ex -> {
                    Platform.runLater(() ->
                            mostraAlert("Errore!", "Errore di rete","Si è verificato un errore di rete, riprovare più tardi",  Alert.AlertType.ERROR)
                    );
                    return null;
                });
    }

    @FXML
    public void openAddTransaction () throws IOException {
        HelloApplication.setRoot("transazione-add-page");
    }

}