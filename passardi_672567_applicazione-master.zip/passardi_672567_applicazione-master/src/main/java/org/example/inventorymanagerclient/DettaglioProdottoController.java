package org.example.inventorymanagerclient;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import org.example.inventorymanagerclient.models.Prodotto;
import org.example.inventorymanagerclient.models.ProdottoSession;

public class DettaglioProdottoController extends BaseController {
    @FXML private Label lblNome;
    @FXML private Label lblSku;
    @FXML private Label lblTipo;
    @FXML private Label lblQuantita;
    @FXML private Label lblMagazzino;
    @FXML private Label lblDescrizione;
    @FXML private Label lblPrezzo;

    @FXML
    public void initialize() {
        Prodotto p = ProdottoSession.getInstance().getProdotto();

        if (p != null) {
            lblNome.setText(p.getNome());
            lblSku.setText(p.getCodiceSku());
            lblTipo.setText(p.getNomeTipo());
            lblQuantita.setText(String.valueOf(p.getQuantita()));
            lblPrezzo.setText(String.format("€ %.2f", p.getPrezzo()));
            if (p.getNomeMagazzino() != null) {
                lblMagazzino.setText(p.getNomeMagazzino());
            } else {
                lblMagazzino.setText("N/D");
            }
            if (p.getDescrizione() != null && !p.getDescrizione().isEmpty()) {
                lblDescrizione.setText(p.getDescrizione());
            } else {
                lblDescrizione.setText("Nessuna descrizione disponibile.");
            }
        }
    }


}
