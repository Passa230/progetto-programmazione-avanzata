package org.example.inventorymanagerclient.dtos;

public class MagazzinoDTO {
    private Long id;
    private String nome;
    private String indirizzo;
    private Long utenteId;

    public MagazzinoDTO() {}

    public MagazzinoDTO(Long id, String nome, String indirizzo, Long utenteId) {
        this.id = id;
        this.nome = nome;
        this.indirizzo = indirizzo;
        this.utenteId = utenteId;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getIndirizzo() { return indirizzo; }
    public void setIndirizzo(String indirizzo) { this.indirizzo = indirizzo; }

    public Long getUtenteId() { return utenteId; }
    public void setUtenteId(Long utenteId) { this.utenteId = utenteId; }

    @Override
    public String toString() {
        return nome + " (" + indirizzo + ")";
    }
}