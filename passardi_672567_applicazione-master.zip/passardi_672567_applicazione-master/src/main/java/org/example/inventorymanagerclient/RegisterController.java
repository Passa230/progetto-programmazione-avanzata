package org.example.inventorymanagerclient;

import com.google.gson.Gson;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import org.example.inventorymanagerclient.requests.RegisterRequest;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class RegisterController extends BaseController {

    @FXML private TextField nameField;
    @FXML private TextField usernameField;
    @FXML private TextField surnameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private TextField phoneField;
    @FXML private TextField codFiscale;
    @FXML private DatePicker dataNascitaField;

    @FXML
    private void handleSignUp(ActionEvent event) {
        String username = usernameField.getText();
        String pass = passwordField.getText();
        String n = nameField.getText();
        String c = surnameField.getText();
        String p = phoneField.getText();
        String f = codFiscale.getText();
        String em = emailField.getText();
        LocalDate dataLocale = dataNascitaField.getValue();

        if (dataLocale == null) {dataLocale = LocalDate.now();}

        String dataFormattata = dataLocale.toString();

        RegisterRequest req = new RegisterRequest(username, pass, n, c, f, p, em, dataFormattata);

        Gson gson = new Gson();
        String json = gson.toJson(req);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/auth/register"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpClient client = HttpClient.newHttpClient();
        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {
                        javafx.application.Platform.runLater(() -> {
                            mostraAlert("Successo!", "Registrazione avvenuta con successo!", "Utente registrato con successo. Ora è possibile accedere al sistema, registrare prodotti e aggiungere magazzini.", Alert.AlertType.CONFIRMATION);
                            try {
                                HelloApplication.setRoot("login-page");
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        });
                    } else {
                        String msg = response.body();
                        javafx.application.Platform.runLater(() -> {
                            mostraAlert("Errore!", "Registrazione fallita", msg, Alert.AlertType.ERROR);
                        });
                    }
                })
                .exceptionally(ex -> {
                    javafx.application.Platform.runLater(() -> {
                        mostraAlert("Errore di rete", "Server non raggiungibile", "Il server non è raggiungibile, riprova più tardi!", Alert.AlertType.ERROR);
                    });
                    return null;
                });
    }



    @FXML
    private void backToLogin(ActionEvent event) throws IOException {
        HelloApplication.setRoot("login-page");
    }
}