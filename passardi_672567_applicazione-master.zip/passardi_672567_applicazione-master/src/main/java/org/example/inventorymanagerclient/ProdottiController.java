package org.example.inventorymanagerclient;

import com.google.gson.Gson;
import javafx.application.Platform;
import javafx.scene.text.Text;
import org.example.inventorymanagerclient.models.MagazzinoSession;
import org.example.inventorymanagerclient.models.Prodotto;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.util.Callback;
import org.example.inventorymanagerclient.models.ProdottoSession;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;

public class ProdottiController extends BaseController {

    @FXML private TableView<Prodotto> prodottiTable;
    @FXML private TableColumn<Prodotto, String> colNome;
    @FXML private TableColumn<Prodotto, String> colSku;
    @FXML private TableColumn<Prodotto, String> colTipo;
    @FXML private TableColumn<Prodotto, Double> colPrezzo;
    @FXML private TableColumn<Prodotto, Void> colAzioni;

    @FXML private Text warehouseName;
    @FXML private Text warehouseAddress;

    private final ObservableList<Prodotto> listaProdotti = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colSku.setCellValueFactory(new PropertyValueFactory<>("codiceSku"));
        colTipo.setCellValueFactory(new PropertyValueFactory<>("nomeTipo"));
        colPrezzo.setCellValueFactory(new PropertyValueFactory<>("prezzo"));

        colNome.setStyle("-fx-alignment: CENTER;");
        colSku.setStyle("-fx-alignment: CENTER;");
        colTipo.setStyle("-fx-alignment: CENTER;");
        colPrezzo.setStyle("-fx-alignment: CENTER;");

        setupActionButtons();

        Long magazzinoId = MagazzinoSession.getInstance().getId();

        caricaProdotti(magazzinoId);

        prodottiTable.setItems(listaProdotti);

        MagazzinoSession m =  MagazzinoSession.getInstance();
        warehouseName.setText(m.getName());
        warehouseAddress.setText(m.getAddress());
    }

    private void setupActionButtons() {
        Callback<TableColumn<Prodotto, Void>, TableCell<Prodotto, Void>> cellFactory = param -> new TableCell<>() {
            private final Button btnSettings = new Button("⚙");
            private final Button btnDelete = new Button("🗑");
           ;
            private final HBox container = new HBox(btnSettings, btnDelete);

            {
                container.setSpacing(10);
                container.setAlignment(javafx.geometry.Pos.CENTER);
                btnSettings.getStyleClass().add("btn-table-settings");
                btnDelete.getStyleClass().add("btn-table-delete");

                btnSettings.setOnAction(e -> {
                    Prodotto prodottoCliccato = getTableView().getItems().get(getIndex());
                    try {
                        handleDetails(prodottoCliccato);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                });
                btnDelete.setOnAction(e -> handleDelete());

            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : container);
            }
        };
        colAzioni.setCellFactory(cellFactory);
    }

    private void caricaProdotti(Long magazzinoId) {
        Gson gson = new Gson();
        String url = "http://localhost:8080/api/prodotti/magazzino/" + magazzinoId;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpClient.newHttpClient()
                .sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {
                        Prodotto[] array = gson.fromJson(response.body(), Prodotto[].class);

                        Platform.runLater(() -> {
                            listaProdotti.clear();
                            if (array != null) {
                                listaProdotti.addAll(Arrays.asList(array));
                            }
                        });
                    } else {
                        Platform.runLater(() ->
                                mostraAlert("Errore!", "Errore del server: " + response.statusCode(), "Errore nel caricamento del prodotti, riprovare più tardi", Alert.AlertType.ERROR)
                        );
                    }
                })
                .exceptionally(ex -> {
                    Platform.runLater(() ->
                            mostraAlert("Errore!", "Errore di rete!", ex.getMessage(),  Alert.AlertType.ERROR)
                    );
                    return null;
                });
    }

    private void handleDetails(Prodotto p) throws IOException {
        ProdottoSession.getInstance().setProdotto(p);
        HelloApplication.setRoot("product-details");
    }
    private void handleDelete() { System.out.println("Azione elimina..."); }

    @FXML
    public void addProdotto() throws IOException {
        HelloApplication.setRoot("prodotto-add-page");
    }
}