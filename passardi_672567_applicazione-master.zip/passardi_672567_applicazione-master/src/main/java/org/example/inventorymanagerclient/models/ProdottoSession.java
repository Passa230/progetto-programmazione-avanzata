package org.example.inventorymanagerclient.models;

public class ProdottoSession {
    private static ProdottoSession instance;
    private Prodotto prodottoSelezionato;

    private ProdottoSession() {}

    public static ProdottoSession getInstance() {
        if (instance == null) {
            instance = new ProdottoSession();
        }
        return instance;
    }

    public Prodotto getProdotto() {
        return prodottoSelezionato;
    }

    public void setProdotto(Prodotto prodotto) {
        this.prodottoSelezionato = prodotto;
    }

    public void clean() {
        this.prodottoSelezionato = null;
    }
}