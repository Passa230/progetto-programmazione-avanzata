package org.example.inventorymanagerclient.models;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transazione {
    private String dataMovimento;
    private String nomeProdotto;
    private String nomeMagazzinoDa;
    private String nomeMagazzinoA;

    public Transazione(LocalDateTime dataMovimento, String nomeProdotto, String nomeMagazzinoDa, String nomeMagazzinoA) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        this.dataMovimento = dataMovimento.format(formatter);

        this.nomeProdotto = nomeProdotto;
        this.nomeMagazzinoDa = (nomeMagazzinoDa != null) ? nomeMagazzinoDa : "N/A";
        this.nomeMagazzinoA = (nomeMagazzinoA != null) ? nomeMagazzinoA : "N/A";
    }

    public String getDataMovimento() { return dataMovimento; }
    public String getNomeProdotto() { return nomeProdotto; }
    public String getNomeMagazzinoDa() { return nomeMagazzinoDa; }
    public String getNomeMagazzinoA() { return nomeMagazzinoA; }
    public String getDataFormattata() {

        LocalDateTime dateTime = LocalDateTime.parse(this.dataMovimento);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return dateTime.format(formatter);
    }
}