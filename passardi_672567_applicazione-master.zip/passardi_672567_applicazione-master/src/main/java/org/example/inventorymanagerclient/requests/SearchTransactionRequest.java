package org.example.inventorymanagerclient.requests;

public class SearchTransactionRequest {
    private Long magazzinoDestinazione;
    private Long magazzinoPartenza;
    private String text;

    public SearchTransactionRequest(Long magazzinoA, Long magazzinoDa, String text) {
        this.magazzinoDestinazione = magazzinoA;
        this.magazzinoPartenza = magazzinoDa;
        this.text = text;
    }

    public Long getMagazzinoDestinazione() {
        return magazzinoDestinazione;
    }

    public Long getMagazzinoPartenza() {
        return magazzinoPartenza;
    }

    public String getText() {
        return text;
    }
}
