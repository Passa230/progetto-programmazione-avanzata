package org.example.inventorymanagerclient.requests;

public class ProdottoRequest {

    private String nome;
    private String codiceSku;
    private String descrizione;
    private int quantita;
    private double prezzo;
    private Long magazzinoId;
    private String nomeTipo;

    public ProdottoRequest() {
    }

    public ProdottoRequest(String nome, String codiceSku, String descrizione, int quantita, double prezzo, Long magazzinoId, String nomeTipo) {
        this.nome = nome;
        this.codiceSku = codiceSku;
        this.descrizione = descrizione;
        this.quantita = quantita;
        this.prezzo = prezzo;
        this.magazzinoId = magazzinoId;
        this.nomeTipo = nomeTipo;
    }

    // 3. Getter e Setter (Noiosi ma necessari senza Lombok)
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCodiceSku() {
        return codiceSku;
    }

    public void setCodiceSku(String codiceSku) {
        this.codiceSku = codiceSku;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public int getQuantita() {
        return quantita;
    }

    public void setQuantita(int quantita) {
        this.quantita = quantita;
    }

    public double getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(double prezzo) {
        this.prezzo = prezzo;
    }

    public Long getMagazzinoId() {
        return magazzinoId;
    }

    public void setMagazzinoId(Long magazzinoId) {
        this.magazzinoId = magazzinoId;
    }

    public String getNomeTipo() {
        return nomeTipo;
    }

    public void setNomeTipo(String nomeTipo) {
        this.nomeTipo = nomeTipo;
    }
}