package org.example.inventorymanagerclient;

import com.google.gson.Gson;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import org.example.inventorymanagerclient.dtos.MagazzinoDTO;
import org.example.inventorymanagerclient.models.Prodotto;
import org.example.inventorymanagerclient.models.UserSession;
import org.example.inventorymanagerclient.requests.TransazioneRequest;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.List;

public class AddTransactionController extends BaseController {
    @FXML private ComboBox<Prodotto> cmbProduct;
    @FXML private TextField txtQuantity;
    @FXML private ComboBox<MagazzinoDTO> cmbDestWarehouse;
    @FXML private DatePicker datePicker;

    private List<MagazzinoDTO> lista;

    @FXML
    public void initialize() {
        Gson gson = new Gson();
        Long utenteId = UserSession.getInstance().getId();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/magazzini/utente/" + utenteId))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpClient.newHttpClient()
                .sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {
                        MagazzinoDTO[] array = gson.fromJson(response.body(), MagazzinoDTO[].class);
                        lista = Arrays.asList(array);
                        cmbDestWarehouse.getItems().addAll(lista);
                    }
                })
                .exceptionally(ex -> {
                    mostraAlert("Impossibile recuperare i dati dal server", "ERRORE DATI", "Non è stato possibil recuperare i dati dal server, riprovare più tardi", Alert.AlertType.ERROR);
                    return null;
                });

        HttpRequest request2 = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/prodotti/all/" + utenteId))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpClient.newHttpClient()
                .sendAsync(request2, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {
                        Prodotto[] array = gson.fromJson(response.body(), Prodotto[].class);
                        List<Prodotto> lista = Arrays.asList(array);
                        cmbProduct.getItems().addAll(lista);
                    } else {
                        System.out.println(response.statusCode());
                    }
                })
                .exceptionally(ex -> {
                    mostraAlert("Impossibile recuperare i dati dal server", "ERRORE DATI", "Non è stato possibil recuperare i dati dal server, riprovare più tardi", Alert.AlertType.ERROR);
                    return null;
                });
    }

    @FXML
    private void handleSave() {
        if (cmbProduct.getValue() == null || cmbDestWarehouse.getValue() == null) {
            mostraAlert("Errore", "Seleziona Prodotto e Magazzino", "Devi selezionare almeno un prodotto e un magazzino per poter procedere", Alert.AlertType.WARNING);
            return;
        }
        Long magazzinoFrom = 0L;
        for (MagazzinoDTO m: this.lista) {
            if (m.getNome().equals(cmbProduct.getValue().getNomeMagazzino())) {
                magazzinoFrom = m.getId();
            }
        }

        TransazioneRequest t = new TransazioneRequest(cmbDestWarehouse.getValue().getId(), cmbProduct.getValue().getId(), datePicker.getValue(), magazzinoFrom);
        Gson gson = new Gson();

        String json = gson.toJson(t);
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/transazioni/aggiungi"))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpClient.newHttpClient().sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        if (response.statusCode() == 200 || response.statusCode() == 201) {
                            mostraAlert("Successo", "Prodotto creato correttamente!", "Prodotto creato correttamente, è possibile visualizzarlo all'interno del magazzino", Alert.AlertType.INFORMATION);
                            try {
                                backToHome();
                            } catch (Exception e) { e.printStackTrace(); }
                        } else {
                            System.out.println(response.statusCode() + " " + response.body());
                            mostraAlert("Errore Server", "Codice: " + response.statusCode() + "\nMsg: " + response.body(), "Errore del server, riprovare più tardi!", Alert.AlertType.ERROR);
                        }
                    });
                })
                .exceptionally(ex -> {
                    Platform.runLater(() -> mostraAlert("Errore Rete", "Errore di rete, controllare lo status code", ("Causa dell'errore: " + ex.getMessage()), Alert.AlertType.ERROR));
                    return null;
                });


    }
}
