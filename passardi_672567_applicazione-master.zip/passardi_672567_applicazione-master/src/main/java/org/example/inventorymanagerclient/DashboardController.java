package org.example.inventorymanagerclient;

import com.google.gson.Gson;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import org.example.inventorymanagerclient.dtos.MagazzinoDTO;
import org.example.inventorymanagerclient.models.UserSession;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.List;

public class DashboardController extends BaseController {

    @FXML private FlowPane warehouseContainer;

    @FXML
    public void initialize() {
        caricaMagazziniDalServer();
    }

    private void caricaMagazziniDalServer() {
        Gson gson = new Gson();
        Long utenteId = UserSession.getInstance().getId();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/magazzini/utente/" + utenteId))
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpClient.newHttpClient()
                .sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {

                        MagazzinoDTO[] array = gson.fromJson(response.body(), MagazzinoDTO[].class);
                        List<MagazzinoDTO> lista = Arrays.asList(array);



                        aggiornaInterfaccia(lista);
                    }
                })
                .exceptionally(ex -> {
                    ex.printStackTrace();
                    return null;
                });

    }

    private void  aggiornaInterfaccia(java.util.List<MagazzinoDTO> lista) {
        Platform.runLater(() -> {
            warehouseContainer.getChildren().clear();
            for (MagazzinoDTO m : lista) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("base-components/magazzino_card.fxml"));
                    VBox card = loader.load();
                    MagazzinoCardController cardController = loader.getController();
                    cardController.setData(m);
                    warehouseContainer.getChildren().add(card);

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });
    }


    @FXML
    private void addNewMagazzino() throws IOException {
        HelloApplication.setRoot("magazzino-add-page");
    }
}