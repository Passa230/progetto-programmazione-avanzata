package org.example.inventorymanagerclient;

import javafx.fxml.FXML;
import javafx.scene.text.Text;
import org.example.inventorymanagerclient.models.UserSession;

import java.io.IOException;

public class AccountController extends BaseController {

    @FXML private Text fullNameText;
    @FXML private Text cfText;
    @FXML private Text birthDateText;
    @FXML private Text usernameText;
    @FXML private Text emailText;
    @FXML private Text phoneText;
    @FXML private Text roleText;
    @FXML private Text idText;

    @FXML
    public void initialize() {

        mockUserData();
    }

    private void mockUserData() {
        UserSession userSession = UserSession.getInstance();

        fullNameText.setText(userSession.getNome() + " " + userSession.getCognome());
        cfText.setText(userSession.getCodFiscale());
        birthDateText.setText(userSession.getDataNascita());
        usernameText.setText(userSession.getUsername());
        emailText.setText(userSession.getEmail());
        phoneText.setText(userSession.getTelefono());
        roleText.setText(userSession.getRuolo());
        idText.setText(Long.toString(userSession.getId()));
    }

    @FXML
    private void handleDeleteAccount(){
        // DA IMPLEMENTARE: Logica di eliminazione dell'account
    }
}