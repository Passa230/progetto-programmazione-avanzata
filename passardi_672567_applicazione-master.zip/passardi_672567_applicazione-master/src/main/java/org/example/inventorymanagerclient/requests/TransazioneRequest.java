package org.example.inventorymanagerclient.requests;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class TransazioneRequest {
    private Long magazzinoAId;
    private Long magazzinoDaId;
    private Long prodottoId;
    private String dataMovimento;

    public TransazioneRequest(Long magazzinoId, Long prodottoId, LocalDate timestamp, Long magazzinoDaId) {
        this.magazzinoAId = magazzinoId;
        this.prodottoId = prodottoId;
        this.dataMovimento = timestamp.atStartOfDay().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        this.magazzinoDaId = magazzinoDaId;
    }

    public String getDataMovimento() {
        return dataMovimento;
    }

    public Long getMagazzinoAId() {
        return magazzinoAId;
    }

    public Long getProdottoId() {
        return prodottoId;
    }

    public Long getMagazzinoDaId() {
        return magazzinoDaId;
    }
}
