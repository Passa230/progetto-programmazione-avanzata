package org.example.inventorymanagerclient.requests;

public class RicercaRequest {
    private String nomeFiltro;
    private String testo;
    private Long userId;

    public RicercaRequest() {

    }

    public RicercaRequest(String testo, String nomeFiltro,  Long userId) {
        this.nomeFiltro = nomeFiltro;
        this.testo = testo;
        this.userId = userId;
    }
    public String getNomeFiltro() {
        return nomeFiltro;
    }

    public String getTesto() {
        return testo;
    }

    public void setNomeFiltro(String nomeFiltro) {
        this.nomeFiltro = nomeFiltro;
    }

    public void setTesto(String testo) {
        this.testo = testo;
    }
}
