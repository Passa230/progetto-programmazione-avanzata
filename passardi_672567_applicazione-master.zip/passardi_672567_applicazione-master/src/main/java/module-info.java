module org.example.inventorymanagerclient {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires java.net.http;
    requires org.slf4j;
    requires javafx.graphics;


    opens org.example.inventorymanagerclient.models to javafx.base, javafx.fxml, com.google.gson;
    opens org.example.inventorymanagerclient.dtos to com.google.gson, javafx.base;

    opens org.example.inventorymanagerclient to javafx.fxml;
    exports org.example.inventorymanagerclient;
    opens org.example.inventorymanagerclient.requests to javafx.base, javafx.fxml, com.google.gson;
}